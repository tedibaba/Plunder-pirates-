from island import Island
from data_structures.heap import MaxHeap


class Mode2Navigator:
    """
    We use store the islands in a heap due to the ability to create a heap is O(n) time where n is the number of islands
    to add into the heap. We recreate the heap each time the add_islands method is called because it creates a faster time
    complexity than using add for each island to be added. Any islands that have a ratio of money to marines less than 2
    will not be added to the heap due it not being viable for the pirates to raid such an island. Since the pirates are 
    optimal strategists, a ratio of less than 2 means its more worth to not raid and earn the 2 points per crew mate they
    have alive. The islands array keeps track of all the islands that have previously been added.

    In regard to adding islands to the heap, we add them based how much a pirate with a certain crew size could hope to obtain
    by raiding that island. This is distinct from adding the money on the island or using the ratio between the money and marines
    as was done in mode1 because if the crew size is smaller than the number of marines, then the money we can obtain is the ratio
    of crew to marines multiplied by the island's money.   

    In simulate_day, the first pirate will choose to raid the island with the greatest ratio. We find this island by using 
    the get_max method on the heap. The other pirates will also raid the island with the greatest ratio until there are no
    more islands left in the heap. For these pirates, they will choose to not do anything as this is the best way to maximise 
    the points they earn.

    """

    def __init__(self, n_pirates: int) -> None:
        """
        :param n_pirates: number of pirates 
        
        :complexity:
            :best case: O(1)
            :worst case: O(1)
        """
        self.n_pirates = n_pirates
        self.islands = []
        self.island_heap = [] #An empty list is initialsed to handle the case when simulate day is called without adding any islands

    def add_islands(self, islands: list[Island]):
        """
        The function adds islands to a list if their money to marines ratio is greater than 2.

        By extending, we do not need to rerun through the islands which have already been added 
        to the list.
        
        :param islands: The `islands` parameter is a list of `Island` objects

        :complexity:
            :best case: O(I)
            :worst case: O(I)
            where I is the number of islands to be added
        """

        self.islands.extend(islands)


    def simulate_day(self, crew: int) -> list[tuple[Island|None, int]]:
        """
        The 'simulate_day' method is used to simulate a day where each pirate is given 'crew' number
        of members to raid with. This method calculates how each pirate will optimally perform their 
        raid (i.e. which island they will go to and how many members they will send) in order to maximize
        their points. 

        We rewrite every island with the number of crew each pirate attacking the island will have. We do this
        so that every island is able to be placed in the heap in such a order that each time we will be able 
        to find an yield that will maximise the pirates points.

        :param crew: The number of crew members given to each pirate
        :return: A list containing the island each pirate will raid and how many crew members they will send over.
        
        :complexity:
            :best case: O(n + clog(n))
            :worst case: O(n + clog(n))
            where n is the number of islands that can be raided, c is the number of pirates
        """

        self.islands = [island for island in self.islands if island.marines > 0 and island.money/island.marines > 2] #filter out the unusable islands
        for island in self.islands:
            island.attackers = crew
        self.island_heap = MaxHeap.heapify(self.islands)

        res = []
        for _ in range(self.n_pirates):
            if len(self.island_heap) > 0 and crew > 0:
                island = self.island_heap.get_max()
                plunder_amount, fight_crew = int((min((crew * island.money)/ island.marines, island.money)) + 0.5), min(crew, island.marines)
                res.append((island, fight_crew))
                island.money -= plunder_amount 
                island.marines -= fight_crew
                if island.marines > 0 and island.money / island.marines > 2:
                    self.island_heap.add(island)
            else:
                res.append((None, 0))
        return res
    


